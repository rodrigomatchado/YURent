﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AspNetCore;
using Microsoft.AspNetCore.Mvc;
using YURent.Data;

namespace YURent.Controllers
{
    public class UtilizadoresController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public ViewResult Registar()
        {
            return View();
        }

        [HttpPost]
        public ViewResult Registar(Utilizador utilizador)
        {
            return View();
        }

    }
}