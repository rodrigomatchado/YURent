﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace YURent.Data
{
    public class YurentContext : DbContext
    {
        public YurentContext(DbContextOptions<YurentContext> options)
            : base(options)
        {

        }

        public DbSet<Utilizadores> Utilizadores { get; set; }


    }    

    
}
