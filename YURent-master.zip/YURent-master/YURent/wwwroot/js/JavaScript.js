﻿$(document).ready(function () {
    $('.imgh')
        .mouseover(function () {
            $(this).attr("src", "~/images/AceitaRecusa/aceitar_hover.png");
        })
        .mouseout(function () {
            $(this).attr("src", "~/images/AceitaRecusa/aceitar.png");
        });
});