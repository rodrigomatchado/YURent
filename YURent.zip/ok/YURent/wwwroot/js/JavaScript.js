﻿(function ($) {
    'use strict';
    /*==================================================================
        [ Daterangepicker ]*/


    try {

        $('#input-start').daterangepicker({
            ranges: true,
            autoApply: true,
            applyButtonClasses: false,
            autoUpdateInput: false
        }, function (start, end) {

            var startDay = start.format('DD/MMM/YYYY');
            var endDay = end.format('DD/MMM/YYYY');

            $('#input-start').val(startDay.replace(/\//g, ' '));
            $('#input-end').val(endDay.replace(/\//g, ' '));
        });

        $('#input-start-2').daterangepicker({
            ranges: true,
            autoApply: true,
            applyButtonClasses: false,
            autoUpdateInput: false
        }, function (start, end) {
            $('#input-start-2').val(start.format('MM/DD/YYYY'));
            $('#input-end-2').val(end.format('MM/DD/YYYY'));
        });

    } catch (er) { console.log(er); }
    /*==================================================================
        [ Single Datepicker ]*/


    try {
        var singleDate = $('.js-single-datepicker');

        singleDate.each(function () {
            var that = $(this);
            var dropdownParent = '#dropdown-datepicker' + that.data('drop');

            that.daterangepicker({
                "singleDatePicker": true,
                "showDropdowns": true,
                "autoUpdateInput": true,
                "parentEl": dropdownParent,
                "opens": 'left',
                "locale": {
                    "format": 'DD/MM/YYYY'
                }
            });
        });

    } catch (er) { console.log(er); }